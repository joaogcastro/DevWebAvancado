console.log("bolinho");


let posX1 = 0;
let posX2 = 0;
let posX3 = 0;
let posX4 = 0;
let posX5 = 0;

function myTimer() {
  posX1 += Math.ceil(Math.random() * 5);
  posX2 += Math.ceil(Math.random() * 5);
  posX3 += Math.ceil(Math.random() * 5);
  posX4 += Math.ceil(Math.random() * 50);
  posX5 += Math.ceil(Math.random() * 5);


  const car1 = document.getElementById("car1");

  if (posX1 > 1900) {
    car1.style.transform = "translatex(" + 1900 + "px)";
    myStop();
  } else {
    car1.style.transform = "translatex(" + posX1 + "px)";
  }

  if (posX2 > 1900) {
    car2.style.transform = "translatex(" + 1900 + "px)";
    myStop();
  } else {
    car2.style.transform = "translatex(" + posX2 + "px)";
  }

  if (posX3 > 1900) {
    car3.style.transform = "translatex(" + 1900 + "px)";
    myStop();
  } else {
    car3.style.transform = "translatex(" + posX3 + "px)";
  }

  if (posX4 > 1900) {
    car4.style.transform = "translatex(" + 1900 + "px)";
    myStop();
  } else {
    car4.style.transform = "translatex(" + posX4 + "px)";
  }

  if (posX5 > 1900) {
    car5.style.transform = "translatex(" + 1900 + "px)";
    myStop();
  } else {
    car5.style.transform = "translatex(" + posX5 + "px)";
  }

}

function myStop() {
  clearInterval(myInterval);
}

function init() {
  const myInterval = setInterval(myTimer, 50);
}